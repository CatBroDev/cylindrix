# Cylindrix browser restoration

An unofficial browser port of Cylindrix, the 1995 vehicle-combat game, continuing [hyperlogic/cylindrix](https://github.com/hyperlogic/cylindrix). The original game, art and community port belong to their respective authors. Old Games Archive contributes compatibility fixes, a reproducible browser build and player integration.

**Status: local release candidate. No public playable page yet.** Custom matches have reached natural wins/losses and can restart. The ten-stage tournament now passes transition/ending tests using the upstream debug shortcut, separately from ordinary gameplay tests. Pilot creation, cumulative statistics, keyboard settings, reload persistence and text-report export have passed browser tests. Physical Android/iOS acceptance remains pending; desktop touch emulation is recorded separately.

## Play and source

The eventual README should link directly to the verified playable page on Old Games Archive. Do not advertise a placeholder or claim that the main website already hosts this restoration. The public repository and playable URL will be added after publication is approved and the preview is reachable.

## What changed

- Restore a Windows x64 baseline and fix pointer-width sound handles and conflicting declarations.
- Reuse the upstream OpenGL renderer with current Emscripten/SDL2, including resize handling and checked legacy-GL compatibility.
- Keep the original 30-Hz simulation with browser frame scheduling.
- Add explicit keyboard/touch lifetime, mute, pause/resume and stop/dispose operations.
- Repair config writes and cumulative pilot statistics; restore them from validated browser-local storage.
- Yield instead of blocking the browser when menus wait for sound or key input.
- Normalize DOS separators inside level records so later tournament stages can load their models.
- Use the website's existing player shell, language dictionaries and configurable touch controls through a versioned iframe protocol.
- Stage only the reviewed custom-match payload. Music, tournament movies and unused later data are not included; originals remain untouched.

This is a restoration of existing code, not a new game or an official release. The upstream port already included browser work before these changes.

## Controls

Arrow keys move and turn; Ctrl fires the laser; Space fires a missile; S switches air/ground mode; X uses the special weapon; V changes the view. A/Z change air speed, Alt plus a direction sidesteps. Enter selects menu items and Esc opens the game menu. F1–F12 issue wingman orders. These mappings come from the original controls reference and the pinned configuration.

Audio starts muted. The browser build currently provides original WAV effects, with no MP3 soundtrack. Pilot records, cumulative statistics and settings persist in local browser storage when it is available. Battles and tournament stages cannot be resumed midway. No server or cloud saves are used.

## Sources and licensing

- Upstream commit: `ee13bd95036331520181eeefe6f12d0638b1ffe8`.
- [Original programmer's release statement](https://www.hardcrawler.com/cylindrix/).
- Historical source archive SHA-256: `50e72af49706b1bba89b2f87143cf154dc6e21b41bf141df7b725ef4a5a9cf08` (outer ZIP).
- Every staged runtime file has a hash and a provenance category in the release asset manifest.

Preserve all original notices. Original source headers specify GNU Library GPL version 2; upstream LICENSE contains LGPL 2.1, while the historical COPYING contains GPLv2. These records are retained separately rather than replaced with a newly invented blanket license. New changes to existing code follow the original file's terms. A release must include its corresponding modified source, build recipe, dependency versions, notices and asset manifest alongside the executable files.

## Publication plan

Prefer a GitHub **fork** named `cylindrix`, retaining the link and history of the upstream project. Publish a dedicated browser branch and scoped release, not the website repository, credentials, SDK cache or test logs. The website remains a separate project.

Offer small, independently reviewable fixes to upstream using pull requests. The first proposed PR is the Windows pointer/declaration fix; browser lifecycle and rendering can follow separately. A useful issue should document a reproducible failure or an unresolved question. Do not post a generic promotional comment.

## Reproduction and evidence

See the release source package's `BUILD.md`, versioned patch files and manifest. Current acceptance records distinguish actual gameplay assertions, desktop touch emulation, viewport screenshots and untested physical devices. A passing build is not a complete-game certification.
